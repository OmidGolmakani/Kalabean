﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kalabean.MVC.Controllers
{
    public class StoresController : Controller
    {
        public IActionResult StoreProfile()
        {
            return View();
        }
    }
}
